How to run the Restaurant Table Booking System (rtbs) Project

1. Download the zip file

2. Extract the file and copy rtbs folder

3.Paste inside root directory(for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/HTML)

4.Open PHPMyAdmin (http://localhost/phpmyadmin)

5. Create a database with the name rrs

6. Import rtbsdb.sql file(given inside the zip package in the SQL file folder)

7. Run the script http://localhost/rrs

Credential for Admin panel :

Username: admin
Password: Test@123