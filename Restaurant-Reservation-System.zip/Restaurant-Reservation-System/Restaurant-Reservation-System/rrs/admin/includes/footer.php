  <footer class="main-footer">
    <div class="float-right d-none d-sm-inline-block">
      &copy; 2024 Developed by Sandeep and Prajwal
    </div>
  </footer>